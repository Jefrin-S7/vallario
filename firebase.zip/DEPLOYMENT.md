# Deploying VALLARIO for $0

This stack deploys entirely on free tiers, no credit card required anywhere:

| Piece | Where | Free tier |
|---|---|---|
| Next.js app (storefront + admin + API routes) | Vercel Hobby plan | Free forever for personal/non-commercial use |
| Auth, Firestore, Storage | Firebase **Spark** plan | Free forever, generous daily quotas |
| Payments | Cashfree + PayPal **sandbox** | Free, unlimited test transactions |
| Transactional email | Resend or Postmark free tier | 100–3,000 emails/month free |

Cloud Functions are intentionally **not** used — Firebase requires the paid
Blaze plan to deploy any Cloud Function at all, even if you'd stay at $0
usage. All of that logic (webhooks, entitlements, downloads, role changes)
runs as Next.js API routes instead, which are free Vercel serverless
functions. See `README.md` for exactly which files that logic lives in.

## 1. Create the Firebase project (Spark/free plan)

1. Go to [console.firebase.google.com](https://console.firebase.google.com) → **Add project**. Decline Google Analytics if asked (optional, doesn't affect cost).
2. **Build → Authentication → Get started.** Enable **Email/Password** and **Google** sign-in methods.
3. **Build → Firestore Database → Create database.** Start in production mode (the rules file below replaces the defaults). Pick any region.
4. **Build → Storage → Get started.** Same region as Firestore.
5. **Project settings (gear icon) → General.** Scroll to "Your apps" → add a **Web app**. Copy the config object — these become your `NEXT_PUBLIC_FIREBASE_*` values.
6. **Project settings → Service accounts → Generate new private key.** This downloads a JSON file — its `project_id`, `client_email`, and `private_key` become `FIREBASE_PROJECT_ID`, `FIREBASE_CLIENT_EMAIL`, `FIREBASE_PRIVATE_KEY`. **Never commit this file.**

## 2. Deploy security rules (no Blaze needed — rules are free on Spark)

```bash
npm install -g firebase-tools
firebase login
firebase use --add        # pick the project you just created
firebase deploy --only firestore:rules,storage:rules
```

This deploys `firebase/firestore.rules` and `firebase/storage.rules`. Skip
`firebase deploy --only functions` entirely — the `firebase/functions`
folder in this repo is left in as a reference/optional upgrade path if you
later move to Blaze; it is not required for the app to work.

## 3. Set up Cashfree (sandbox — free)

1. Sign up at [merchant.cashfree.com](https://merchant.cashfree.com).
2. Dashboard defaults to **Test Mode** — stay there for now. Go to **Developers → API Keys** and copy the test **Client ID** / **Client Secret**.
3. **Developers → Webhooks → Add webhook.** URL: `https://<your-vercel-domain>/api/payments/cashfree/webhook`. Copy the generated **webhook secret**.
4. These become `CASHFREE_CLIENT_ID`, `CASHFREE_CLIENT_SECRET`, `CASHFREE_WEBHOOK_SECRET`, with `CASHFREE_ENV=sandbox`.

## 4. Set up PayPal (sandbox — free)

1. Sign up at [developer.paypal.com](https://developer.paypal.com) → **Dashboard → Apps & Credentials**, Sandbox tab.
2. **Create App.** Copy the Client ID / Secret → `PAYPAL_CLIENT_ID`, `PAYPAL_CLIENT_SECRET`.
3. Under the app, add a webhook: `https://<your-vercel-domain>/api/payments/paypal/webhook`, subscribed to `PAYMENT.CAPTURE.COMPLETED`, `PAYMENT.CAPTURE.DENIED`, `PAYMENT.CAPTURE.REFUNDED`. Copy the **Webhook ID** → `PAYPAL_WEBHOOK_ID`.
4. Set `PAYPAL_ENV=sandbox`.

## 5. (Optional) Email — Resend free tier

1. Sign up at [resend.com](https://resend.com) (3,000 emails/month free).
2. Create an API key → `EMAIL_PROVIDER_API_KEY`.
3. Implement the actual send in `src/lib/server/email.ts` (the fetch call is stubbed and commented in) — until then, emails just log to the server console, which is fine for testing.

## 6. Deploy to Vercel

1. Push this repo to GitHub.
2. [vercel.com](https://vercel.com) → **Add New → Project** → import the repo. Framework preset auto-detects Next.js.
3. Before the first deploy, add every variable from `.env.example` under **Settings → Environment Variables** (paste real values, not the placeholders). For `FIREBASE_PRIVATE_KEY`, paste the whole multi-line key — Vercel's env var editor handles the newlines correctly.
4. Deploy. Vercel gives you a `https://your-project.vercel.app` URL — set `NEXT_PUBLIC_SITE_URL` to that (or your custom domain, also free to attach on Hobby) and redeploy so `robots.txt`/`sitemap.xml` emit correct absolute URLs.
5. Go back and update the Cashfree/PayPal webhook URLs (step 3–4 above) to point at your real deployed domain if you used a placeholder.

## 7. Seed the product catalog into Firestore

The six real products already live in `src/lib/data/products.ts` and render
correctly from local seed data with zero setup. To make them purchasable for
real, they also need to exist as Firestore docs (so orders/entitlements can
reference them) and their actual deliverable files need to be in Storage:

1. Firestore: create a `products/{productId}` doc per entry in
   `src/lib/data/products.ts`, matching the shape in
   `src/lib/firebase/schema.md`. A one-time script using `adminDb()` from
   `src/lib/firebase/admin.ts` is the fastest way — loop over the array and
   `.set()` each one.
2. Storage: upload each product's real deliverable file (zip, PDF, etc.) to
   `products/{productId}/original/{fileName}`, and set that same `fileName`
   on the Firestore doc (`/api/downloads/sign` reads it from there).
3. Upload the marketing images already in `public/products/` to
   `public/{productId}/...` in Storage only if you want them served from
   Firebase CDN instead of Vercel's — not required, since Vercel already
   serves `public/` for free.

## 8. Test the full loop before going live

1. Register a test account at `/register`.
2. Add a product to cart, check out with **Cashfree test mode** — use their [published test card/UPI numbers](https://www.cashfree.com/docs/payments/online/resources/sandbox-environment).
3. Confirm the webhook fires (Cashfree dashboard → Developers → Webhooks → delivery log) and that `orders/{id}.status` flips to `paid` in Firestore, an `entitlements` doc appears, and the product shows up in `/dashboard`.
4. Repeat with a PayPal sandbox buyer account.
5. Only after that loop works end-to-end should you flip `CASHFREE_ENV`/`PAYPAL_ENV` to live and swap in production credentials — in a **separate** set of Vercel environment variables for a production deployment, never mixed with sandbox (per the original spec's environment-separation requirement).

## Staying free as you grow

- Vercel Hobby: fine for personal projects; commercial use technically
  requires a Pro plan ($20/mo) per Vercel's terms — worth checking current
  terms before launching a real business on it.
- Firebase Spark: no Cloud Functions, and Firestore/Storage have daily quota
  caps (50K reads, 20K writes, 1GB stored, 10GB egress/month as of this
  writing) — comfortable for early traffic, but check
  [firebase.google.com/pricing](https://firebase.google.com/pricing) for
  current numbers before you scale.
- If you outgrow Spark, moving to Blaze doesn't require re-architecting:
  the `firebase/functions` folder in this repo already has equivalent
  Cloud Functions implementations ready to deploy alongside (or instead of)
  the Vercel API routes.
