# VALLARIO

Premium digital-product e-commerce platform — storefront, customer dashboard,
and admin/ERP console — built with Next.js (App Router), Tailwind, and a
Firebase backend architecture.

## What this is, honestly

This repo is a **complete, working frontend** plus a **production-ready
backend written as real code** — Firestore/Storage security rules, a
payment-provider abstraction (Cashfree + PayPal), and the actual server
logic (webhooks, entitlement granting, download signing, role management)
running as Next.js API routes so the whole thing deploys for free. It is
**not** wired to a live Firebase project or live Cashfree/PayPal accounts —
that requires credentials only you can create. Everything needed to go live
is here in code form; connecting it is a config step, documented in
[DEPLOYMENT.md](./DEPLOYMENT.md).

Run `npm run dev` right now and the entire storefront, customer dashboard,
and admin console work end-to-end against local seed data — no setup
required. Auth forms detect the missing Firebase config and run in a labeled
"demo mode" instead of crashing.

## What's real vs. demo, precisely

| Area | Status |
|---|---|
| Storefront UI (home, shop, product pages, cart, checkout UI) | **Real**, renders from `src/lib/data/products.ts` |
| The 6 product images + logo | **Your real uploaded assets**, in `public/products` and `public/brand` |
| Product catalog data (names, prices, what's included) | **Real**, matches your spec exactly — no fabricated review counts or sales figures |
| Firestore/Storage security rules | **Real**, deploy-ready (`firebase/firestore.rules`, `firebase/storage.rules`) |
| Payment webhooks, entitlement granting, download signing, role changes | **Real logic**, live at `src/app/api/**` — runs as free Vercel serverless functions, no Blaze plan needed |
| Cloud Functions (`firebase/functions/`) | **Optional alternative** — same logic, only needed if you move to Firebase's paid Blaze plan later |
| Admin/ERP dashboard, orders, customers, finance, analytics, coupons, reviews, support, audit logs | **Real UI**, backed by clearly-badged demo data (`src/lib/data/admin-demo.ts`) — swap for Firestore queries once connected |
| Payments (Cashfree/PayPal) | **Reference implementation** in `src/lib/payments/` — needs real API keys to process a live payment |
| Auth (email/password, Google) | Real Firebase Auth calls, but falls back to demo mode with no project connected |

## Getting it running locally

```bash
npm install
npm run dev
```

Open `http://localhost:3000` for the storefront, `http://localhost:3000/admin`
for the ERP console. Everything renders and browses freely with zero setup.
Actions that require a real backend — completing checkout, downloading a
purchased file, changing a user's role — will return a clear "sign in
required" or "not configured" message rather than crashing, until you
connect a real Firebase project per DEPLOYMENT.md.

## Going to production, for free

See **[DEPLOYMENT.md](./DEPLOYMENT.md)** for a full step-by-step, $0-cost
deployment guide (Vercel + Firebase Spark plan, no credit card required
anywhere). Short version:

1. Create a Firebase project (Spark/free plan) — Auth, Firestore, Storage.
2. `firebase deploy --only firestore:rules,storage:rules` (free on Spark).
3. Get free Cashfree + PayPal sandbox credentials.
4. Push to GitHub, import into Vercel, add the env vars, deploy.
5. Seed the catalog into Firestore and upload the real product files to
   Storage.

Cloud Functions (`firebase/functions/`) are **not** required for this path —
Firebase only lets you deploy Cloud Functions on the paid Blaze plan, so all
of that logic (webhooks, entitlements, downloads, role changes) has been
built as Next.js API routes instead, which run free on Vercel. The
`firebase/functions` folder is kept as a reference/optional upgrade path if
you later move to Blaze for other reasons — nothing in the free deployment
path depends on it.

## Where things live

```
src/app/                    storefront + admin routes (App Router)
src/app/admin/(dashboard)/  admin/ERP pages, sidebar-shell layout
src/app/admin/login/        admin sign-in, deliberately outside the shell
src/app/api/                the actual backend: payment create/webhook routes,
                             download signing, auth/role admin routes, cron
src/components/             storefront UI components
src/components/admin/       admin UI components
src/lib/data/products.ts    the real 6-product seed catalog
src/lib/data/admin-demo.ts  clearly-labeled admin demo data
src/lib/firebase/           client SDK (browser) + Admin SDK (server-only)
src/lib/server/             free-tier backend logic: auth verification,
                             audit log, entitlement granting, email
src/lib/payments/           PaymentProvider abstraction (Cashfree, PayPal)
firebase/firestore.rules    deny-by-default Firestore security rules
firebase/storage.rules      Storage security rules (products never public)
firebase/functions/src/     OPTIONAL: Cloud Functions equivalents of the
                             src/app/api/ logic above — only needed on Blaze
```

## Security posture already built in

- Firestore rules deny everything by default; customers can never write
  price, order status, entitlements, or their own role from the browser.
- Every order-creating, download-signing, and role-changing API route
  verifies a real Firebase ID token server-side (`src/lib/server/auth.ts`)
  — nothing trusts a uid/email/role the client claims in a request body.
- Checkout requires a signed-in account (entitlements are keyed by uid), and
  every line item is re-priced from the trusted server-side catalog, never
  from a client-submitted price.
- Digital product files are never in a public Storage path — every download
  goes through `/api/downloads/sign`, which checks auth + a live,
  non-revoked entitlement + remaining download count before minting a
  15-minute signed URL, and logs the issuance.
- Cashfree webhook signatures are verified with the correct HMAC input
  (`timestamp + rawBody`, matching what Cashfree actually signs) using a
  constant-time, length-checked comparison. PayPal webhooks are verified via
  PayPal's own `verify-webhook-signature` endpoint — both were previously
  stubbed/broken (see git history) and are now real.
- Payment webhooks dedupe via `webhookEvents/{eventId}` before ever
  touching an order or granting access, so a provider's automatic retry
  can't double-grant a purchase.
- Every sensitive admin action funnels through `writeAuditLog`
  (`src/lib/server/audit.ts`), which is append-only and unreachable from the
  normal admin UI.
- HTTP responses carry `X-Frame-Options`, `X-Content-Type-Options`,
  `Referrer-Policy`, and `Permissions-Policy` headers (`next.config.ts`);
  the `X-Powered-By` header is disabled. A strict Content-Security-Policy is
  intentionally not included yet — several components use inline `style`
  attributes for dynamic colors, which a strict `style-src` would block.
  Adding one is worth doing before launch; budget time to audit those
  inline styles first.

## Known gaps in the free-tier (Vercel + Spark) path

- **Review verified-purchase enforcement** currently only exists in the
  optional `firebase/functions/src/reviews.ts` (a Firestore trigger, which
  needs Blaze). There's no review-submission UI yet either — reviews are
  currently display-only. If you build a submission flow before adding
  Blaze, route it through an API route that checks the entitlement
  server-side first (mirror the pattern in `/api/downloads/sign`), rather
  than trusting a client-set `verifiedPurchase` flag.
- **Role changes and new-user provisioning** are implemented as API routes
  (`/api/admin/users/[uid]/role`, `/api/auth/register`) rather than Firestore
  triggers — functionally equivalent, but they only run when someone hits
  those routes, not automatically on every possible Firestore write path.
  Fine as long as all role/user-creation writes go through them, which is
  the only path the admin UI and auth forms actually use.
- **Transactional email** logs to the console until you wire in a real
  provider in `src/lib/server/email.ts` (see DEPLOYMENT.md step 5).

## Quality checks passing

- `npm run lint` — zero errors, zero warnings (strict `@typescript-eslint`
  rules, no `any` types, no unescaped JSX entities).
- `npm run build` — full production build succeeds, all 38 routes compile
  and prerender (or correctly render dynamically for the API routes).
- `firebase/functions` — separate TypeScript project, compiles clean with
  `npm run build` inside that folder.
- Branded `not-found.tsx` (real 404 status) and `error.tsx` (client error
  boundary) replace Next.js's default pages.
- `robots.txt` and `sitemap.xml` are generated from the real product catalog
  (`src/app/robots.ts`, `src/app/sitemap.ts`) — set `NEXT_PUBLIC_SITE_URL`
  once you have a real domain.
- Shop search is live (filters by name/description/category/tags), and the
  header search icon and wishlist deep link both point at real, working
  destinations — a stale `/dashboard?tab=wishlist` link and a dead search
  button were fixed.
- A real `/support` page now backs the dashboard's "Support" nav item,
  which previously 404'd.
