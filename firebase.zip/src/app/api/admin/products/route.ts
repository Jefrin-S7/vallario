import { NextRequest, NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { adminDb } from "@/lib/firebase/admin";
import { requireUserOrBypass, UnauthenticatedError } from "@/lib/server/auth";
import { products as catalogSeed } from "@/lib/data/products";
import { writeAuditLog } from "@/lib/server/audit";

// GET /api/admin/products
export async function GET(req: NextRequest) {
  try {
    await requireUserOrBypass(req);
    const db = adminDb();

    const snap = await db.collection("products").get();
    if (snap.empty) {
      // Return seed catalog if collection is not yet seeded
      return NextResponse.json({
        products: catalogSeed,
        source: "seed",
        unseeded: true,
      });
    }

    const products = snap.docs.map((d) => ({
      id: d.id,
      ...d.data(),
    }));

    return NextResponse.json({
      products,
      source: "firestore",
      unseeded: false,
    });
  } catch (err) {
    if (err instanceof UnauthenticatedError) {
      return NextResponse.json({ message: err.message }, { status: 401 });
    }
    console.error("Admin products error:", err);
    return NextResponse.json({ message: "Failed to load products." }, { status: 500 });
  }
}

// PATCH /api/admin/products
// Body: { id, price?, compareAtPrice?, status?, featured?, bestseller? }
export async function PATCH(req: NextRequest) {
  try {
    const caller = await requireUserOrBypass(req);
    const db = adminDb();

    const body = await req.json();
    const { id, ...updates } = body;

    if (!id) {
      return NextResponse.json({ message: "Product id is required." }, { status: 400 });
    }

    const productRef = db.collection("products").doc(id);
    const snap = await productRef.get();

    if (!snap.exists) {
      // If product document does not exist yet, find in seed and create it
      const seedItem = catalogSeed.find((p) => p.id === id);
      if (!seedItem) {
        return NextResponse.json({ message: "Product not found." }, { status: 404 });
      }
      await productRef.set({
        ...seedItem,
        ...updates,
        updatedAt: new Date().toISOString().slice(0, 10),
      });
    } else {
      await productRef.update({
        ...updates,
        updatedAt: new Date().toISOString().slice(0, 10),
      });
    }

    if (!caller.bypassed) {
      await writeAuditLog({
        action: "product_updated",
        actorUid: caller.uid,
        targetId: id,
        targetType: "product",
        metadata: updates,
      });
    }

    return NextResponse.json({ ok: true, id, updates });
  } catch (err) {
    if (err instanceof UnauthenticatedError) {
      return NextResponse.json({ message: err.message }, { status: 401 });
    }
    console.error("Admin update product error:", err);
    return NextResponse.json({ message: "Failed to update product." }, { status: 500 });
  }
}
