import { NextRequest, NextResponse } from "next/server";
import { adminDb } from "@/lib/firebase/admin";
import { requireUserOrBypass, UnauthenticatedError } from "@/lib/server/auth";
import { products as catalogSeed } from "@/lib/data/products";
import { writeAuditLog } from "@/lib/server/audit";

// POST /api/admin/seed
export async function POST(req: NextRequest) {
  try {
    const caller = await requireUserOrBypass(req);
    const db = adminDb();

    const batch = db.batch();
    for (const p of catalogSeed) {
      const ref = db.collection("products").doc(p.id);
      batch.set(
        ref,
        {
          ...p,
          createdAt: p.createdAt || new Date().toISOString(),
          updatedAt: p.updatedAt || new Date().toISOString(),
        },
        { merge: true }
      );
    }

    await batch.commit();

    if (!caller.bypassed) {
      await writeAuditLog({
        action: "catalog_seeded_to_firestore",
        actorUid: caller.uid,
        targetId: "products",
        targetType: "catalog",
        metadata: { count: catalogSeed.length },
      });
    }

    return NextResponse.json({
      ok: true,
      message: `Successfully seeded ${catalogSeed.length} products to Firestore.`,
      count: catalogSeed.length,
    });
  } catch (err) {
    if (err instanceof UnauthenticatedError) {
      return NextResponse.json({ message: err.message }, { status: 401 });
    }
    console.error("Admin seed error:", err);
    return NextResponse.json({ message: "Failed to seed catalog." }, { status: 500 });
  }
}
