import ProductionBadge from "./ProductionBadge";

export default function DemoBadge({ label }: { label?: string }) {
  return <ProductionBadge label={label || "Live Firestore"} />;
}
