import { Database, ShieldCheck } from "lucide-react";

export default function ProductionBadge({
  projectId = "vallario-7fa6d",
  label = "Live Firestore",
}: {
  projectId?: string;
  label?: string;
}) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald/30 bg-emerald/10 text-emerald px-3 py-1 text-xs font-semibold shadow-xs">
      <span className="relative flex h-2 w-2">
        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald opacity-75"></span>
        <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald"></span>
      </span>
      <Database size={13} />
      <span>{label}</span>
      <span className="font-mono text-[10px] text-emerald/80 border-l border-emerald/20 pl-1.5 ml-0.5">
        {projectId}
      </span>
    </span>
  );
}
