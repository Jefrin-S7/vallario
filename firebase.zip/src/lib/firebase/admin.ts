import "server-only";
import fs from "fs";
import path from "path";
import { getApps, initializeApp, cert, App } from "firebase-admin/app";
import { getFirestore } from "firebase-admin/firestore";
import { getAuth } from "firebase-admin/auth";
import { getStorage } from "firebase-admin/storage";

// Firebase Admin SDK — server only (Next.js API routes / server actions).
// Uses a service-account key and bypasses Firestore/Storage security rules
// entirely.

function cleanEnv(val?: string): string {
  if (!val) return "";
  return val.trim().replace(/^["']|["']$/g, "");
}

function getAdminApp(): App {
  if (getApps().length) return getApps()[0];

  let projectId = cleanEnv(process.env.FIREBASE_PROJECT_ID);
  let clientEmail = cleanEnv(process.env.FIREBASE_CLIENT_EMAIL);
  let privateKey = cleanEnv(process.env.FIREBASE_PRIVATE_KEY)?.replace(/\\n/g, "\n");
  const storageBucket =
    cleanEnv(process.env.FIREBASE_STORAGE_BUCKET) ||
    cleanEnv(process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET) ||
    "vallario-7fa6d.firebasestorage.app";

  // Fallback to serviceaccountkey.json if env vars are incomplete
  if (!projectId || !clientEmail || !privateKey) {
    const serviceAccountPath = path.resolve(process.cwd(), "serviceaccountkey.json");
    if (fs.existsSync(serviceAccountPath)) {
      try {
        const fileContent = JSON.parse(fs.readFileSync(serviceAccountPath, "utf8"));
        projectId = projectId || fileContent.project_id;
        clientEmail = clientEmail || fileContent.client_email;
        privateKey = privateKey || fileContent.private_key?.replace(/\\n/g, "\n");
      } catch (err) {
        console.error("Failed to parse serviceaccountkey.json fallback", err);
      }
    }
  }

  if (!projectId || !clientEmail || !privateKey) {
    throw new Error(
      "Firebase Admin is not configured. Set FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, " +
        "and FIREBASE_PRIVATE_KEY in .env.local, or place serviceaccountkey.json in project root."
    );
  }

  return initializeApp({
    credential: cert({ projectId, clientEmail, privateKey }),
    storageBucket,
  });
}

export function adminDb() {
  return getFirestore(getAdminApp());
}

export function adminAuth() {
  return getAuth(getAdminApp());
}

export function adminStorage() {
  return getStorage(getAdminApp()).bucket();
}
