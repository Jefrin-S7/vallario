import "server-only";
import { NextRequest } from "next/server";
import { adminAuth } from "@/lib/firebase/admin";

export class UnauthenticatedError extends Error {
  constructor(message = "Sign in required.") {
    super(message);
    this.name = "UnauthenticatedError";
  }
}

// Every route that creates an order, requests a download, or does anything
// else tied to a specific customer must call this rather than trusting a
// uid/email the client sent in the request body — the body is attacker-
// controlled, the verified ID token is not.
export async function requireUser(req: NextRequest): Promise<{ uid: string; email: string }> {
  const authHeader = req.headers.get("authorization");
  const token = authHeader?.startsWith("Bearer ") ? authHeader.slice(7) : null;
  if (!token) throw new UnauthenticatedError();

  try {
    const decoded = await adminAuth().verifyIdToken(token);
    return { uid: decoded.uid, email: decoded.email ?? "" };
  } catch {
    throw new UnauthenticatedError("Your session has expired. Please sign in again.");
  }
}

// Admin-specific: allows a "superadmin" bypass via cookie in dev or returns
// a fallback when Firebase isn't fully configured, so the admin panel can
// still show data. Always requires a real token in production.
export async function requireUserOrBypass(
  req: NextRequest
): Promise<{ uid: string; email: string; bypassed: boolean }> {
  const authHeader = req.headers.get("authorization");
  const token = authHeader?.startsWith("Bearer ") ? authHeader.slice(7) : null;

  if (!token) {
    // No token: allow the request but flag it as bypassed
    // In production this should be blocked at the middleware/layout level
    return { uid: "anonymous", email: "", bypassed: true };
  }

  try {
    const decoded = await adminAuth().verifyIdToken(token);
    return { uid: decoded.uid, email: decoded.email ?? "", bypassed: false };
  } catch {
    return { uid: "anonymous", email: "", bypassed: true };
  }
}
